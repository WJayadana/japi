const chalk = require("chalk")
const fs = require("fs")



//DATA AKUN ORDER KOUTA
//WAJIB DI ISI
const idOrkut = "OK*****" //ganti dengan id orkut kamu
const pwOrkut = "***************" //ganti dengan pw orkut kamu
const pinOrkut = "****" //ganti dengan pin orkut kamu
const apiOrkut = "-" //isi dengan apikey orkut kamu 
global.qris_string = "-" //isi dengan code qris kamu


//SETTINGAN TOPUP
global.untung = "2"
  //Ini profit yg kamu dapat, 2 = 2% maka harga akan meningkat 1%
  //Isi sesuai kebutuhan 
  global.batas_waktu_deposit = "15m" //batas expired payment deposit
  global.batas_waktu_pay_topup = "5m" //batas expired payment Topup 
  //15m = 15 menit, ganti sesuai kebutuhan wajib dibelakang ada huruf m
  
  
//===== SETTINGAN BOT
  global.ownerNumber = "6285791220179@s.whatsapp.net"
  global.kontakOwner = "6285791220179"
  global.namaStore = "Nama store mu"
  global.botName = "Nama bot mu"
  global.ownerName = "Nama mu"
  
  
  //=== SOSIAL MEDIA
  global.linkgc1 = "Link grup wa mu"
  global.linkgc2 = "Link grup wa mu ke 2"
  global.linkyt = "link chanel yt lu"
  global.linkig = "link akun ig lu"
  global.sawer = "--"


//PAYMENT 
const payment = {
    dana: {
      nomer: "085xxxx",
      atas_nama: "RAMA**"
    }
}
global.dana = "085xxx"
global.ovo = "085xxx"
global.gopay = "085xxx"
// kalau gada, isi dengan "--"



//==============================================
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
module.exports = { payment, idOrkut, pwOrkut, pinOrkut, apiOrkut }